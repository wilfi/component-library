import React from 'react';
import ReactDOM from 'react-dom';
import 'regenerator-runtime/runtime';
import { IntlProvider } from 'react-intl';
import normalizeWidgetInput from '../../common/normalizeWidgetInput';
import MyWidget from './components/MyWidget';
import widgetDefinition from './MyWidget.widget';

import { RenderFn } from '../../types/widgets';

const render: RenderFn = async function (instanceId, langCode, origin, cb) {
  const { element, locale, messages } = await normalizeWidgetInput(
    instanceId,
    langCode,
    widgetDefinition,
  );
  if (!element || !locale) {
    return;
  }
  let greeting = element.getAttribute('data-greeting');
  switch (greeting) {
    case 'Hello':
    case 'Hi':
    case 'Howdy':
      break;
    default:
      greeting = null;
  }
  const userName = element.getAttribute('data-name');
  const excitement = element.getAttribute('data-excitement');
  ReactDOM.render(
    <IntlProvider locale={locale} messages={messages}>
      <MyWidget
        greeting={greeting || 'Hello'}
        name={userName || ''}
        excitement={Boolean(excitement)}
      />
    </IntlProvider>,
    element,
    () => cb(element),
  );
};

export default render;
