import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import MyWidget, { MyWidgetProps } from './MyWidget';
import { Locale } from '../../../types/locale';
import storyWithTranslation from '../lib/storyWithTranslation';

const stories: Meta<MyWidgetProps> = {
  title: 'Widgets/My Widget/Components/MyWidget',
  component: MyWidget,
  decorators: [storyWithTranslation()],
};

const Template: StoryFn<MyWidgetProps> = (args) => <MyWidget {...args} />;

export const Default = Template.bind({});
Default.args = {
  greeting: 'Hello',
  name: 'Alice',
  excitement: false,
};

export const Hi = Template.bind({});
Hi.args = {
  greeting: 'Hi',
  name: 'Alice',
  excitement: false,
};

export const Howdy = Template.bind({});
Howdy.args = {
  greeting: 'Howdy',
  name: 'Alice',
  excitement: false,
};

export const WithExcitement = Template.bind({});
WithExcitement.args = {
  greeting: 'Howdy',
  name: 'Alice',
  excitement: true,
};

export const WithExcitementHi = Template.bind({});
WithExcitementHi.args = {
  greeting: 'Hi',
  name: 'Bob',
  excitement: true,
};

export const WithExcitementEmoji = Template.bind({});
WithExcitementEmoji.args = {
  greeting: 'Hi',
  name: '🎉',
  excitement: true,
};

export const Spanish = Template.bind({});
Spanish.args = { greeting: 'Hi', name: 'Alícia', excitement: false };
Spanish.decorators = [storyWithTranslation(Locale.ES)];

export default stories;
