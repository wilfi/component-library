import React, { CSSProperties, ReactElement } from 'react';
import { FormattedMessage } from 'react-intl';

export interface MyWidgetProps {
  /**
   * One of the predefined greetings.
   *
   * @default Hello
   */
  greeting: 'Hello' | 'Hi' | 'Howdy';
  /**
   * The name of the user to greet.
   */
  name: string;
  /**
   * Set to true to greet with excitement.
   *
   * @default false
   */
  excitement: boolean;
}

const styles: Record<string, CSSProperties> = {
  container: {
    width: '15em',
    backgroundColor: 'white',
    borderRadius: '6px',
    boxShadow: '1px 1px 5px rgba(0, 0, 0, 0.3)',
    padding: '2em',
  },
  heading: {
    fontSize: '1.4em',
    fontWeight: 'bold',
    textDecoration: 'underline',
    marginBottom: '0.7em',
  },
};

const MyWidget = ({
  greeting,
  name,
  excitement,
}: MyWidgetProps): ReactElement => (
  <div style={styles.container}>
    <h5 style={styles.heading}>
      <FormattedMessage defaultMessage="Greeting" id="TvLEtg" />
    </h5>
    <div>
      {greeting}, <em>{name}</em>
      {excitement ? '!' : '.'}
    </div>
  </div>
);

export default MyWidget;
